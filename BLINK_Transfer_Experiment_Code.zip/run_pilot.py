"""Smoke-test, forecast, or verify the signed Qwen-to-BLINK transfer pilot."""

import argparse
from datetime import datetime, timezone
import fcntl
from hashlib import sha256
from importlib.metadata import version
from pathlib import Path
from time import perf_counter

import torch
import torch.nn.functional as F
from PIL import Image
from peft import LoraConfig, TaskType, get_peft_model
from transformers import AutoProcessor, Qwen2_5_VLForConditionalGeneration

from prepare_data import (
    LETTERS, SOURCES, SWAP_TARGETS, TARGETS, read_json, write_json,
)


MODEL = "Qwen/Qwen2.5-VL-3B-Instruct"
MODEL_REV = "66285546d2b821cf421d4f5eb2576359d3770cd3"
LR, ADAM_EPS, BATCH_SIZE = 1e-4, 1e-8, 8
SCALES = (1, 4)


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def save_tensors(path, state):
    tmp = path.with_suffix(".tmp")
    torch.save(state, tmp)
    tmp.replace(path)


def attach_lora(base):
    modules = [name for name, _ in base.named_modules()
               if name.endswith((".self_attn.q_proj", ".self_attn.v_proj"))
               and "visual" not in name.split(".")]
    if len(modules) != 2 * base.config.text_config.num_hidden_layers:
        raise RuntimeError("Expected two decoder attention targets per layer.")
    recipe = LoraConfig(task_type=TaskType.CAUSAL_LM, target_modules=modules,
                        r=8, lora_alpha=16, lora_dropout=0, bias="none")
    return get_peft_model(base, recipe)


class Engine:
    def __init__(self, data, config):
        if not torch.cuda.is_available():
            raise RuntimeError("Select a CUDA GPU runtime and check nvidia-smi.")
        self.device = torch.device("cuda:0")
        self.data = data
        self.dtype = {"bf16": torch.bfloat16, "fp16": torch.float16}[
            config["precision"]
        ]
        if self.dtype == torch.bfloat16:
            if not torch.cuda.is_bf16_supported(including_emulation=False):
                raise RuntimeError("Use --precision fp16 for a T4 smoke test.")
        self.loss_scale = 128.0 if self.dtype == torch.float16 else 1.0

        torch.manual_seed(config["seed"])
        self.processor = AutoProcessor.from_pretrained(
            MODEL, revision=MODEL_REV, use_fast=True,
            min_pixels=64 * 28 * 28, max_pixels=config["image_tokens"] * 28 * 28,
        )
        base = Qwen2_5_VLForConditionalGeneration.from_pretrained(
            MODEL, revision=MODEL_REV, dtype=self.dtype,
            attn_implementation="sdpa", device_map={"": 0},
        )
        self.model = attach_lora(base)
        # Evaluation mode fixes dropout. Autograd still works in this mode.
        self.model.eval()
        self.params = {n: p for n, p in self.model.named_parameters()
                       if p.requires_grad}
        if any("lora_" not in n or p.dtype != torch.float32
               for n, p in self.params.items()):
            raise RuntimeError("Only FP32 decoder LoRA weights should train.")
        self.answer_ids = self.check_letters()

    def check_letters(self):
        tokenizer = self.processor.tokenizer
        prompt = self.processor.apply_chat_template(
            [{"role": "user", "content": "Pick one answer letter."}],
            tokenize=False, add_generation_prompt=True,
        )
        prefix = tokenizer.encode(prompt, add_special_tokens=False)
        out = []
        for letter in LETTERS[:4]:
            tokens = tokenizer.encode(letter, add_special_tokens=False)
            joined = tokenizer.encode(prompt + letter, add_special_tokens=False)
            if len(tokens) != 1 or joined != prefix + tokens:
                raise ValueError(f"{letter} is not a single answer continuation.")
            out.append(tokens[0])
        return out

    def logits(self, row):
        pictures = []
        for path in row["images"]:
            with Image.open(self.data / path) as image:
                pictures.append(image.convert("RGB"))
        content = [{"type": "image", "image": image} for image in pictures]
        content.append({"type": "text", "text": row["question"] +
                        "\nReply with one uppercase option letter only."})
        prompt = self.processor.apply_chat_template(
            [{"role": "user", "content": content}], tokenize=False,
            add_generation_prompt=True,
        )
        inputs = self.processor(text=[prompt], images=pictures,
                                return_tensors="pt").to(self.device)
        inputs["pixel_values"] = inputs["pixel_values"].to(self.dtype)
        return self.model(**inputs, use_cache=False,
                          logits_to_keep=1).logits[:, -1, :].float()

    def loss(self, logits, row):
        gold = self.answer_ids[row["answer"]]
        label = torch.tensor([gold], device=self.device)
        return F.cross_entropy(logits, label)

    def backward_mean(self, rows):
        if not rows:
            raise ValueError("An empty batch cannot produce a gradient.")
        self.model.zero_grad(set_to_none=True)
        total = 0.0
        for row in rows:
            loss = self.loss(self.logits(row), row)
            (loss * self.loss_scale / len(rows)).backward()
            total += loss.detach()
        for param in self.params.values():
            if param.grad is None:
                raise RuntimeError("A LoRA weight is disconnected from loss.")
            param.grad.div_(self.loss_scale)
        norm = torch.nn.utils.clip_grad_norm_(
            list(self.params.values()), float("inf"), error_if_nonfinite=True,
        )
        return float(total / len(rows)), float(norm)

    @torch.inference_mode()
    def scores(self, rows):
        results = []
        for row in rows:
            logits = self.logits(row)
            answer = row["answer"]
            ids = self.answer_ids[:len(row["choices"])]
            if len(ids) != len(row["choices"]):
                raise ValueError("Expected between two and four choices.")
            valid = logits[0, ids]
            loss = self.loss(logits, row)
            values = torch.cat((valid, loss.reshape(1))).tolist()
            options, loss_value = values[:-1], values[-1]
            prediction = max(range(len(options)), key=options.__getitem__)
            wrong = options[:answer] + options[answer + 1:]
            margin = options[answer] - max(wrong)
            results.append(dict(id=row["id"], group=row["group"], gold=answer,
                                prediction=prediction, margin=margin,
                                loss=loss_value, correct=prediction == answer))
        return results

    def snapshot(self):
        return {name: param.detach().cpu().clone()
                for name, param in self.params.items()}

    @torch.no_grad()
    def restore(self, weights):
        if weights.keys() != self.params.keys():
            raise ValueError("The saved adapter does not match this model.")
        for name, param in self.params.items():
            param.copy_(weights[name])


def swapped(rows):
    return [dict(row, images=[row["images"][0], row["images"][2],
                             row["images"][1]], answer=1 - row["answer"])
            for row in rows]


def soft_correct(margin):
    return min(1.0, max(0.0, margin + 0.5))


def probe_call(values, zero=1e-8):
    if all(value < -zero for value in values):
        return "negative"
    if all(value > zero for value in values):
        return "positive"
    return "uncertain"


def probe_scores(before, after, before_swap=None, after_swap=None):
    n = len(before)
    gains = sum(not a["correct"] and b["correct"] for a, b in zip(before, after))
    losses = sum(a["correct"] and not b["correct"] for a, b in zip(before, after))
    margin_points = 100 * sum(
        soft_correct(b["margin"]) - soft_correct(a["margin"])
        for a, b in zip(before, after)
    ) / n
    result = dict(margin=margin_points, gains=gains, losses=losses, loss=sum(
        a["loss"] - b["loss"] for a, b in zip(before, after)
    ) / n)
    if before_swap is not None:
        paired, average_swap = 0.0, 0.0
        for a, b, c, d in zip(before, after, before_swap, after_swap):
            change = ((b["margin"] - a["margin"]) +
                      (d["margin"] - c["margin"])) / 2
            start = a["margin"]
            paired += soft_correct(start + change) - soft_correct(start)
            average_swap += soft_correct(d["margin"]) - soft_correct(c["margin"])
        result["paired"] = 100 * paired / n
        result["two_order_control"] = (margin_points + 100 * average_swap / n) / 2
    return result


def target_views(manifest):
    views = {task: manifest["targets"][task]["forecast"] for task in TARGETS}
    for task in SWAP_TARGETS:
        views[task + "_swapped"] = swapped(views[task])
    return views


def forecast(engine, manifest, config, run_dir, manifest_path):
    initial = engine.snapshot()
    views = target_views(manifest)
    before = {name: engine.scores(rows) for name, rows in views.items()}
    forecasts = {}
    for source in SOURCES:
        print(f"Forecasting {source}", flush=True)
        engine.backward_mean(manifest["sources"][source]["probe"])
        # Simulate the first AdamW step from zero moments and no decay.
        update = {}
        for name, param in engine.params.items():
            grad = param.grad.detach().cpu()
            update[name] = -LR * grad / (grad.abs() + ADAM_EPS)
        engine.model.zero_grad(set_to_none=True)

        per_scale = {}
        try:
            for scale in SCALES:
                engine.restore({name: initial[name] + scale * update[name]
                                for name in initial})
                per_scale[scale] = {name: engine.scores(rows)
                                    for name, rows in views.items()}
        finally:
            engine.restore(initial)

        forecasts[source] = {}
        for task in TARGETS:
            swap_name = task + "_swapped"
            scores = [probe_scores(before[task], per_scale[scale][task],
                                   before.get(swap_name),
                                   per_scale[scale].get(swap_name))
                      for scale in SCALES]
            methods = ["margin", "loss"]
            if task in SWAP_TARGETS:
                methods.extend(("paired", "two_order_control"))
            calls = {key: probe_call([entry[key] for entry in scores])
                     for key in methods}
            forecasts[source][task] = dict(n=len(views[task]), scores=scores,
                                           calls=calls)
            print(f"  {task}: {calls}", flush=True)

    init_file = run_dir / "initial_adapter.pt"
    save_tensors(init_file, initial)
    runtime = {name: version(name) for name in ("torch", "transformers", "peft")}
    if engine.device.type == "cuda":
        runtime.update(gpu=torch.cuda.get_device_name(engine.device),
                       cuda=torch.version.cuda)
    record = dict(config=config, forecasts=forecasts, model=MODEL,
                  model_revision=MODEL_REV, runtime=runtime,
                  jigsaw_origin=manifest.get("jigsaw_origin"),
                  manifest_sha256=digest(manifest_path),
                  init_sha256=digest(init_file), code_sha256=digest(Path(__file__)),
                  saved_utc=datetime.now(timezone.utc).isoformat())
    write_json(run_dir / "forecasts.json", record)


def train_source(engine, rows, steps, checkpoint):
    optimizer = torch.optim.AdamW(list(engine.params.values()), lr=LR,
                                  eps=ADAM_EPS, weight_decay=0.0)
    first = 0
    if checkpoint.exists():
        saved = torch.load(checkpoint, map_location="cpu", weights_only=True)
        engine.restore(saved["weights"])
        optimizer.load_state_dict(saved["optimizer"])
        first = saved["step"]
        print(f"Resuming {checkpoint.stem} after step {first}", flush=True)
    for step in range(first, steps):
        start = BATCH_SIZE * step
        batch = rows[start:start + BATCH_SIZE]
        if len(batch) != BATCH_SIZE:
            raise ValueError("The source training split is too small.")
        loss, _ = engine.backward_mean(batch)
        optimizer.step()
        if (step + 1) % 16 == 0 or step + 1 == steps:
            save_tensors(checkpoint, dict(step=step + 1, weights=engine.snapshot(),
                                          optimizer=optimizer.state_dict()))
            print(f"  step {step + 1}/{steps}, loss {loss:.3f}", flush=True)
    engine.model.zero_grad(set_to_none=True)


def verify(engine, manifest, config, run_dir, initial):
    targets = {task: manifest["targets"][task]["evaluation"] for task in TARGETS}
    base_file = run_dir / "base.json"
    if not base_file.exists():
        engine.restore(initial)
        print("Scoring held-out base Qwen", flush=True)
        write_json(base_file, dict(
            targets={task: engine.scores(rows) for task, rows in targets.items()},
            sources={s: engine.scores(manifest["sources"][s]["holdout"])
                     for s in SOURCES},
        ))
    for source in SOURCES:
        destination = run_dir / f"{source}.json"
        if destination.exists():
            continue
        print(f"Training and evaluating {source}", flush=True)
        engine.restore(initial)
        rows = manifest["sources"][source]
        train_source(engine, rows["train"], config["steps"],
                     run_dir / f"checkpoint_{source}.pt")
        engine.model.save_pretrained(run_dir / ("adapter_" + source))
        write_json(destination, dict(
            targets={task: engine.scores(rows) for task, rows in targets.items()},
            source_holdout=engine.scores(rows["holdout"]),
        ))


def smoke(engine, manifest):
    # Warm up the GPU and check the broadest image patterns before timing.
    torch.cuda.reset_peak_memory_stats()
    for source in SOURCES:
        rows = manifest["sources"][source]["probe"][:2]
        engine.backward_mean(rows)
        start = perf_counter()
        loss, norm = engine.backward_mean(rows)
        if norm <= 0 or not (0 <= loss < float("inf")):
            raise RuntimeError(f"Invalid loss or zero gradient on {source}.")
        print(f"{source}: {(perf_counter() - start) / len(rows):.3f} s "
              f"per forward+backward; loss {loss:.3f}; grad norm {norm:.4f}")
    engine.model.zero_grad(set_to_none=True)
    for task, rows in target_views(manifest).items():
        engine.scores(rows[:1])
        start = perf_counter()
        results = engine.scores(rows[:2])
        steps = len(results)
        print(f"{task}: {(perf_counter() - start) / steps:.3f} s per forward")
    print(f"Peak allocated: {torch.cuda.max_memory_allocated() / 2**30:.2f} GiB")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="action", required=True)
    for action in ("smoke", "forecast", "verify"):
        command = sub.add_parser(action)
        command.add_argument("--data", type=Path, default=Path("data"))
        if action != "smoke":
            command.add_argument("--run", type=Path, required=True)
        if action != "verify":
            command.add_argument("--precision", choices=("bf16", "fp16"),
                                 default="bf16")
            command.add_argument("--image-tokens", type=int, default=256)
            command.add_argument("--seed", type=int, default=17)
        if action == "forecast":
            command.add_argument("--steps", type=int, choices=(32, 64), default=64)
    args = parser.parse_args()
    manifest_path = args.data / "pilot.json"
    manifest = read_json(manifest_path)
    if args.action != "verify":
        if args.image_tokens < 64:
            parser.error("--image-tokens must be at least 64.")
        config = dict(precision=args.precision, image_tokens=args.image_tokens,
                      seed=args.seed, steps=getattr(args, "steps", 0),
                      lr=LR, eps=ADAM_EPS, batch_size=BATCH_SIZE, scales=SCALES)
    if args.action == "smoke":
        smoke(Engine(args.data, config), manifest)
        return

    args.run.mkdir(parents=True, exist_ok=True)
    with (args.run / ".lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        forecast_file = args.run / "forecasts.json"
        if args.action == "forecast":
            if forecast_file.exists():
                parser.error("This run already has forecasts. Use a new --run.")
            forecast(Engine(args.data, config), manifest, config, args.run,
                     manifest_path)
            return
        if not forecast_file.exists():
            parser.error("Run forecast before verify.")
        frozen = read_json(forecast_file)
        initial = args.run / "initial_adapter.pt"
        if (frozen["manifest_sha256"] != digest(manifest_path) or
                frozen["init_sha256"] != digest(initial) or
                frozen["code_sha256"] != digest(Path(__file__)) or
                frozen["model_revision"] != MODEL_REV):
            parser.error("The data, initialization, or experiment code changed.")
        config = frozen["config"]
        verify(Engine(args.data, config), manifest, config, args.run,
               torch.load(initial, map_location="cpu", weights_only=True))


if __name__ == "__main__":
    main()
