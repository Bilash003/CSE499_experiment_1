"""Build fixed source splits and labeled BLINK target splits on CPU."""

import argparse
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from io import BytesIO
import json
from pathlib import Path
import random
import re
from urllib.request import urlopen

from PIL import Image, ImageDraw, ImageOps


BLINK = "BLINK-Benchmark/BLINK"
BLINK_REV = "a3666eb249237ba3d5eca8db21176cc47967e040"
SOURCES = ("Jigsaw", "Relative_Reflectance")
TARGETS = ("Spatial_Relation", "Object_Localization",
           "Visual_Similarity", "Art_Style")
SWAP_TARGETS = ("Visual_Similarity", "Art_Style")
SOURCE_SIZES = {"probe": 64, "train": 512, "holdout": 32}
LETTERS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".webp"}
HASH_DISTANCE = 3


def read_json(path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path, value):
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(json.dumps(value, indent=2, allow_nan=False) + "\n",
                   encoding="utf-8")
    tmp.replace(path)


def fingerprint(image):
    """A 64-bit difference hash for resized or re-encoded copies."""
    pixels = image.convert("L").resize((9, 8)).get_flattened_data()
    bits = 0
    for y in range(8):
        for x in range(8):
            i = 9 * y + x
            bits = (bits << 1) | (pixels[i] > pixels[i + 1])
    return bits


def near_copy(key, keys):
    return any((key ^ other).bit_count() <= HASH_DISTANCE for other in keys)


def save_image(root, name, image):
    image = image.convert("RGB")
    image.thumbnail((896, 896), Image.Resampling.LANCZOS)
    path = root / "images" / (name + ".png")
    path.parent.mkdir(parents=True, exist_ok=True)
    image.save(path)
    return str(path.relative_to(root))


def example(uid, images, question, choices, answer, **metadata):
    if not 2 <= len(choices) <= 4 or not 0 <= answer < len(choices) or not images:
        raise ValueError(f"Invalid options, label, or images for {uid}")
    return dict(id=uid, group=uid, images=images, question=question,
                choices=choices, answer=answer, **metadata)


def labeled_prompt(question, choices):
    options = "\n".join(f"({LETTERS[i]}) {choice}"
                        for i, choice in enumerate(choices))
    return question.strip() + "\n" + options


def blink_example(root, task, index, item):
    uid = str(item["idx"])
    choices = [str(choice).strip() for choice in item["choices"]]
    answer = re.fullmatch(r"\(?([A-Z])\)?\.?", item["answer"].strip().upper())
    if answer is None:
        raise ValueError(f"Expected a labeled BLINK val row for {uid}")
    gold = LETTERS.index(answer[1])
    images = [item[f"image_{i}"] for i in range(1, 5)]
    images = [image for image in images if image is not None]
    if task in SWAP_TARGETS and (len(images) != 3 or len(choices) != 2):
        raise ValueError(f"Expected a reference and two candidates for {uid}")
    prompt = (item.get("prompt") or item["question"]).strip()
    prompt = re.sub(r"<image\s*\d*>", "", prompt, flags=re.IGNORECASE)
    if not all(f"({letter})" in prompt for letter in LETTERS[:len(choices)]):
        prompt = labeled_prompt(prompt, choices)
    paths = [save_image(root, f"{task}/{index:04d}-{j}", im)
             for j, im in enumerate(images)]
    return example(uid, paths, prompt, choices, gold), [
        fingerprint(image) for image in images
    ]


def split_targets(rows, fingerprints, rng):
    # Link examples that share any exact or near-duplicate image.
    parents = list(range(len(rows)))

    def find(i):
        while i != parents[i]:
            i = parents[i]
        return i

    seen = []
    for i, keys in enumerate(fingerprints):
        for j, previous in seen:
            if any(near_copy(key, previous) for key in keys):
                parents[find(i)] = find(j)
        seen.append((i, keys))

    groups = defaultdict(list)
    for i, row in enumerate(rows):
        groups[find(i)].append(row)
    blocks = list(groups.values())
    for block in blocks:
        for row in block:
            row["group"] = block[0]["id"]

    # Find the largest whole-group split at or below 32 questions.
    rng.shuffle(blocks)
    limit = min(32, len(rows) - 1)
    available = {0: ()}
    for i, block in enumerate(blocks):
        for count, picked in list(available.items()):
            total = count + len(block)
            if total <= limit and total not in available:
                available[total] = picked + (i,)
    chosen = set(available[max(available)])
    if not chosen:
        raise ValueError("Image groups cannot form a small forecast split.")
    forecast = [row for i in sorted(chosen) for row in blocks[i]]
    held_out = [row for i, block in enumerate(blocks)
                if i not in chosen for row in block]
    return dict(forecast=forecast, evaluation=held_out)


def build_targets(root, rng):
    from datasets import load_dataset

    targets, all_keys = {}, []
    for task in TARGETS:
        items = load_dataset(BLINK, task, split="val", revision=BLINK_REV)
        pairs = [blink_example(root, task, i, item)
                 for i, item in enumerate(items)]
        rows, keys = zip(*pairs)
        targets[task] = split_targets(rows, keys, rng)
        all_keys.extend(key for item_keys in keys for key in item_keys)
        print(task, {k: len(v) for k, v in targets[task].items()}, flush=True)
    return targets, all_keys


def fetch_photo(cache, url):
    local = cache / (sha256(url.encode()).hexdigest() + ".png")
    if local.exists():
        return url, local
    try:
        with urlopen(url, timeout=15) as response:
            data = response.read(16_000_001)
        if len(data) > 16_000_000:
            return None
        with Image.open(BytesIO(data)) as image:
            tmp = local.with_suffix(".tmp")
            ImageOps.exif_transpose(image).convert("RGB").save(tmp, format="PNG")
            tmp.replace(local)
        return url, local
    except (OSError, ValueError, Image.DecompressionBombError):
        return None


def tara_candidates(path, cache, rng):
    if path.is_dir():
        paths = sorted(p for p in path.rglob("*")
                       if p.suffix.lower() in IMAGE_EXTS)
        rng.shuffle(paths)
        yield from ((str(p.relative_to(path)), p) for p in paths)
        return
    with path.open(encoding="utf-8") as file:
        lines = (line.strip() for line in file if line.strip())
        urls = [json.loads(line).get("image_url") if path.suffix == ".jsonl"
                else line for line in lines]
    urls = sorted({url for url in urls if isinstance(url, str)
                   and url.startswith(("https://", "http://"))})
    if not urls:
        raise ValueError("No image_url entries found in the TARA training file.")
    rng.shuffle(urls)
    cache.mkdir(parents=True, exist_ok=True)
    received = 0
    with ThreadPoolExecutor(max_workers=8) as pool:
        for start in range(0, len(urls), 16):
            block = urls[start:start + 16]
            for item in pool.map(lambda url: fetch_photo(cache, url), block):
                if item is not None:
                    received += 1
                    yield item
            if start >= 48 and received == 0:
                raise RuntimeError("No TARA photos reached in 64 attempts. "
                                   "Check the photo host or use local photos.")


def select_photos(path, cache, forbidden, rng):
    selected, keys = [], []
    for origin, file in tara_candidates(path, cache, rng):
        try:
            with Image.open(file) as raw:
                image = ImageOps.exif_transpose(raw).convert("RGB")
        except OSError:
            continue
        if min(image.size) < 160:
            continue
        key = fingerprint(image)
        if near_copy(key, forbidden) or near_copy(key, keys):
            continue
        keys.append(key)
        square = ImageOps.fit(image, (448, 448),
                              method=Image.Resampling.LANCZOS)
        selected.append((origin, square))
        if len(selected) % 100 == 0:
            print(f"Prepared {len(selected)} Jigsaw photos", flush=True)
        if len(selected) == sum(SOURCE_SIZES.values()):
            return selected, keys
    raise ValueError(f"Found {len(selected)} usable Jigsaw training photos. "
                     "Supply at least 608 distinct, readable images.")


def build_jigsaw(root, photos, rng):
    result, offset = {}, 0
    for split, count in SOURCE_SIZES.items():
        pool = photos[offset:offset + count]
        offset += count
        rows = []
        for i, (origin, image) in enumerate(pool):
            distractor, other = pool[(i + 1) % count]
            x, y = rng.choice((0, 224)), rng.choice((0, 224))
            box = (x, y, x + 224, y + 224)
            masked = image.copy()
            masked.paste((0, 0, 0), box)
            options = [image.crop(box), other.crop(box)]
            answer = i % 2
            if answer:
                options.reverse()
            uid = f"jigsaw-{split}-{i:04d}"
            paths = [save_image(root, f"jigsaw/{uid}-{j}", picture)
                     for j, picture in enumerate([masked, *options])]
            choices = ["the second image", "the third image"]
            question = "Which tile fills the black square in the first image?"
            rows.append(example(uid, paths, labeled_prompt(question, choices),
                                choices, answer, origin=[origin, distractor]))
        rng.shuffle(rows)
        result[split] = rows
    return result


def reflectance_points(annotation):
    points = {p["id"]: p for p in annotation.get("intrinsic_points", [])
              if p.get("opaque", True)}
    valid = []
    for comparison in annotation.get("intrinsic_comparisons", []):
        p = points.get(comparison["point1"])
        q = points.get(comparison["point2"])
        gold = comparison.get("darker")
        confidence = comparison.get("darker_score") or 0
        if p and q and gold in ("1", "2", "E") and confidence > 0:
            distance = ((p["x"] - q["x"]) ** 2 + (p["y"] - q["y"]) ** 2)
            if distance >= 0.17 ** 2:
                valid.append((confidence, p, q, gold))
    if valid:
        _, p, q, gold = max(valid, key=lambda item: item[0])
        return p, q, {"1": 0, "2": 1, "E": 2}[gold]
    return None


def mark_points(image, points):
    image.thumbnail((768, 768), Image.Resampling.LANCZOS)
    draw = ImageDraw.Draw(image)
    radius = max(6, round(min(image.size) * 0.019))
    for point, color in zip(points, ("red", "blue")):
        x = point["x"] * (image.width - 1)
        y = point["y"] * (image.height - 1)
        box = (x - radius, y - radius, x + radius, y + radius)
        draw.ellipse(box, fill=color, outline="white", width=2)
    return image


def build_reflectance(root, directory, forbidden, rng):
    files = sorted(p for p in directory.rglob("*.json")
                   if p.with_suffix(".png").is_file())
    rng.shuffle(files)
    rows, keys = [], []
    choices = ["red point", "blue point", "about the same"]
    prompt = labeled_prompt("Which marked surface is darker in material "
                            "reflectance, ignoring illumination?", choices)
    for file in files:
        comparison = reflectance_points(read_json(file))
        if comparison is None:
            continue
        try:
            with Image.open(file.with_suffix(".png")) as raw:
                image = raw.convert("RGB")
        except OSError:
            continue
        key = fingerprint(image)
        if near_copy(key, forbidden) or near_copy(key, keys):
            continue
        keys.append(key)
        p, q, answer = comparison
        if rng.random() < 0.5:
            p, q = q, p
            answer = 1 - answer if answer < 2 else 2
        uid = f"reflectance-{len(rows):04d}"
        path = save_image(root, f"reflectance/{uid}", mark_points(image, [p, q]))
        rows.append(example(uid, [path], prompt, choices, answer,
                            origin=str(file.relative_to(directory))))
        if len(rows) == sum(SOURCE_SIZES.values()):
            break
    if len(rows) != sum(SOURCE_SIZES.values()):
        raise ValueError(f"Found {len(rows)} usable IIW scenes. Pass the full "
                         "archive's extracted folder with PNG/JSON pairs.")
    result, offset = {}, 0
    for split, count in SOURCE_SIZES.items():
        result[split] = rows[offset:offset + count]
        offset += count
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    picture_source = parser.add_mutually_exclusive_group(required=True)
    picture_source.add_argument("--tara", type=Path,
                                help="TARA train.jsonl or train photo folder")
    picture_source.add_argument("--oxford-pets", type=Path,
                                help="Extracted Oxford-IIIT Pet images folder")
    parser.add_argument("--iiw", required=True, type=Path,
                        help="Extracted full IIW archive")
    parser.add_argument("--output", type=Path, default=Path("data"))
    parser.add_argument("--seed", type=int, default=17)
    args = parser.parse_args()
    pictures = args.tara if args.tara else args.oxford_pets
    if not pictures.exists() or not args.iiw.is_dir():
        parser.error("Check the Jigsaw input and extracted IIW paths.")
    if args.oxford_pets and not pictures.is_dir():
        parser.error("Pass the extracted Oxford image directory.")
    root = args.output
    root.mkdir(parents=True, exist_ok=True)
    manifest = root / "pilot.json"
    if manifest.exists():
        parser.error("Choose a new --output folder to change data or seed.")
    rng = random.Random(args.seed)
    targets, keys = build_targets(root, rng)
    photos, photo_keys = select_photos(pictures, root / "tara_cache", keys, rng)
    sources = {"Jigsaw": build_jigsaw(root, photos, rng)}
    sources["Relative_Reflectance"] = build_reflectance(
        root, args.iiw, keys + photo_keys, rng
    )
    write_json(manifest, dict(blink_revision=BLINK_REV, data_seed=args.seed,
                              jigsaw_origin="TARA train" if args.tara else "Oxford-IIIT Pet",
                              sources=sources, targets=targets))
    print(f"Prepared {manifest}")


if __name__ == "__main__":
    main()
