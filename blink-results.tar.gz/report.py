"""Calculate paired accuracy changes and forecast performance on CPU."""

import argparse
from collections import defaultdict
import csv
from pathlib import Path

import numpy as np

from prepare_data import SOURCES, SWAP_TARGETS, TARGETS, read_json, write_json


MATERIAL_DROP = 5.0
BOOTSTRAPS = 5000


def accuracy(rows):
    return 100 * sum(row["correct"] for row in rows) / len(rows)


def paired_result(base, adapted):
    new = {row["id"]: row for row in adapted}
    if len(new) != len(adapted) or len(base) != len(new) or (
            set(new) != {row["id"] for row in base}):
        raise ValueError("Base and adapter must score the same unique items.")
    changes = defaultdict(list)
    for row in base:
        other = new[row["id"]]
        if (row["group"], row["gold"]) != (other["group"], other["gold"]):
            raise ValueError("Group or answer changed between evaluations.")
        changes[row["group"]].append(int(other["correct"]) - int(row["correct"]))
    gains = sum(c == 1 for items in changes.values() for c in items)
    losses = sum(c == -1 for items in changes.values() for c in items)
    delta = 100 * (gains - losses) / len(base)
    lower, upper = None, None
    if len(changes) >= 2:
        totals = np.array([sum(items) for items in changes.values()])
        counts = np.array([len(items) for items in changes.values()])
        rng = np.random.default_rng(17)
        draws = rng.integers(0, len(totals), size=(BOOTSTRAPS, len(totals)))
        resampled = 100 * totals[draws].sum(axis=1) / counts[draws].sum(axis=1)
        lower, upper = map(float, np.quantile(resampled, [0.025, 0.975]))
    status = "uncertain_or_small"
    if upper is not None and delta <= -MATERIAL_DROP and upper < 0:
        status = "clear_negative"
    if lower is not None and delta >= MATERIAL_DROP and lower > 0:
        status = "clear_positive"
    return dict(n=len(base), groups=len(changes), base_pct=accuracy(base),
                lora_pct=accuracy(adapted), delta_pp=delta, ci_low=lower,
                ci_high=upper, gained=gains, lost=losses, outcome=status)


def metrics(rows, method):
    called = [row for row in rows if row[method] != "uncertain"]
    warned = [row for row in rows if row[method] == "negative"]
    actual = [row for row in rows if row["outcome"] == "clear_negative"]
    hits = sum(row[method] == "negative" for row in actual)
    false_alarms = sum(
        row["ci_low"] is not None and row["ci_low"] > -MATERIAL_DROP
        and row["outcome"] != "clear_negative" for row in warned
    )
    return dict(pairs=len(rows), called=len(called), warnings=len(warned),
                clear_negatives=len(actual), hits=hits, false_alarms=false_alarms,
                unresolved_warnings=len(warned) - hits - false_alarms,
                coverage=len(called) / len(rows),
                recall=hits / len(actual) if actual else None,
                precision_resolved=hits / (hits + false_alarms)
                if hits + false_alarms else None)


def collect(run):
    frozen = read_json(run / "forecasts.json")
    base = read_json(run / "base.json")
    rows = []
    for source in SOURCES:
        adapted = read_json(run / f"{source}.json")
        source_delta = paired_result(base["sources"][source],
                                     adapted["source_holdout"])["delta_pp"]
        for task in TARGETS:
            forecast = frozen["forecasts"][source][task]
            result = paired_result(base["targets"][task], adapted["targets"][task])
            dataset = frozen["jigsaw_origin"] if source == "Jigsaw" else "IIW"
            row = dict(source=source, source_dataset=dataset,
                       target=task, n_forecast=forecast["n"],
                       source_holdout_delta_pp=source_delta, **result)
            for method in ("margin", "loss", "paired", "two_order_control"):
                row[method] = forecast["calls"].get(method)
                for scale, record in zip(frozen["config"]["scales"], forecast["scores"]):
                    row[f"{method}_{scale}x"] = record.get(method)
            rows.append(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--run", required=True, type=Path)
    args = parser.parse_args()
    rows = collect(args.run)
    paired = [row for row in rows if row["target"] in SWAP_TARGETS]
    summary = {
        "all_pairs": {m: metrics(rows, m) for m in ("margin", "loss")},
        "two_candidate_pairs": {m: metrics(paired, m) for m in
                                ("margin", "paired", "two_order_control")},
    }
    csv_path = args.run / "results.csv"
    temp = csv_path.with_suffix(".tmp")
    with temp.open("w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    temp.replace(csv_path)
    write_json(args.run / "summary.json", summary)
    for row in rows:
        print(f"{row['source']} -> {row['target']}: "
              f"forecast {row['margin']}, measured {row['delta_pp']:+.2f} pp "
              f"({row['outcome']})")
    print(f"Wrote {csv_path} and summary.json")


if __name__ == "__main__":
    main()
